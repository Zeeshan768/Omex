# Contributing

I am grateful for any and all contributions.

If it's a minor thing I guess it's easier to open an issue, but if you prefer creating a fork, go ahead! :)
